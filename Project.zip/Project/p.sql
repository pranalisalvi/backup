create table Users (
 login_id varchar2(5) primary key,
 password varchar2(10),
 role varchar2(5)
) ;

Insert into  Users values('A202','jaini','admin');
Insert into  Users values('A203','nikhil','mac');
Insert into  Users values('A204','pranali','mac');



  ALTER TABLE Users
ADD CONSTRAINT user_check CHECK (role in ('admin','mac'));


 Insert into  Participant values('1','nikhil@gmail.com',1001,'501');
 Insert into  Participant values('2','pansaren@ymail.com',1003,'502');
 
 
 SELECT appl.Application_id,appl.full_name,appl.status,appl.Scheduled_program_id FROM Application appl JOIN Programs_Scheduled ps ON appl.Scheduled_program_id=ps.Scheduled_program_id WHERE((status='confirmed')AND(start_date='13-JUN-2017' AND end_date='13-SEP-2017'));