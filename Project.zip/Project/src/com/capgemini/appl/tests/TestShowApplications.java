package com.capgemini.appl.tests;



import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.appl.dao.UniversityDao;
import com.capgemini.appl.dao.UniversityDaoImpl;
import com.capgemini.appl.exception.UniversityAdmissionException;

public class TestShowApplications {
UniversityDao dao;
	@Before
	public void setup() throws UniversityAdmissionException {
		dao = new UniversityDaoImpl();  //add this code
	}

	@Test
	public void testShowApplications() {
		try {
			assertNotNull(dao.showApplications());
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}
}
