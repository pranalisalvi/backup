package com.capgemini.appl.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.appl.dao.UniversityDao;
import com.capgemini.appl.dao.UniversityDaoImpl;
import com.capgemini.appl.dto.Application;
import com.capgemini.appl.exception.UniversityAdmissionException;

public class TestAcceptOrRejectApplication {
	UniversityDao dao;
	@Before
	public void setup() throws UniversityAdmissionException {
		dao = new UniversityDaoImpl();  
	}
	
	@Test
	public void testAcceptOrRejectApplication() {
		Application application= new Application(1080,"accepted");
		try {
			assertEquals(true,dao.acceptOrRejectApplication(application));
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown() throws Exception {
		dao=null;
	}

}
