package com.capgemini.appl.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.appl.dao.UniversityDaoImpl;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

public class TestUpdateProgram {
	UniversityService service;
	
	@Before
	public void setup() throws UniversityAdmissionException {
		service = new UniversityServiceImpl();  //add this code
	}

	
	@Test
	public void testUpdateProgram() {
		ProgramsOffered p= new ProgramsOffered("DB","Basics of Big Data","IT  professionals/ engineers",9,"OCPJ");
		try {
			assertEquals(true,service.updateProgram(p));
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@After
	public void tearDown() throws Exception {
		service=null;
	}
}
