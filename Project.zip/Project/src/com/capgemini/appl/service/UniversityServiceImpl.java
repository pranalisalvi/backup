package com.capgemini.appl.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.appl.dao.UniversityDao;
import com.capgemini.appl.dao.UniversityDaoImpl;
import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;

public class UniversityServiceImpl implements UniversityService {
	UniversityDao dao = null;
	Users users;

	public UniversityServiceImpl() throws UniversityAdmissionException {
		dao = new UniversityDaoImpl();
	}

	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {
		return dao.showApplications();
	}

	@Override
	public boolean addProgram(ProgramsOffered p)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.addProgram(p);
	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.acceptOrRejectApplication(application);
	}

	@Override
	public boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.deleteProgram(ProgramName);
	}

	@Override
	public boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.updateProgram(p);
	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.showProgramsOffereds();
	}

	@Override
	public Users getUserDetail(String userName)
			throws UniversityAdmissionException {

		return dao.getUserDetail(userName);
	}

	@Override
	public String isUserAuthanticate(String userName, String password)
			throws UniversityAdmissionException {
		users = dao.getUserDetail(userName);
		String pwd = users.getPassword();
		if (password.equals(pwd)) {
			String role = users.getRole();
			System.out.println("role" + role);
			return role;
		} else {
			throw new UniversityAdmissionException("Invalid User");
		}

	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled()
			throws UniversityAdmissionException {

		return dao.getAllProgramSheduled();
	}

	@Override
	public List<Application> getApplicationOnSheduledId(String ScheduleId)
			throws UniversityAdmissionException {

		return dao.getApplicationOnSheduledId(ScheduleId);
	}

	@Override
	public boolean updateApplicationDB(int id, String status)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.updateApplicationDB(id, status);
	}

	@Override
	public List<Application> showApplicantInfo(int id)
			throws UniversityAdmissionException {

		return dao.showApplicantInfo(id);
	}

	@Override
	public int getApplicationId() throws UniversityAdmissionException {

		return dao.getApplicationId();
	}

	@Override
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {

		return dao.showAll();
	}

	@Override
	public int addApplicant(Application appl)
			throws UniversityAdmissionException {

		return dao.addApplicant(appl);
	}

	@Override
	public Application showStatus(int application_id)
			throws UniversityAdmissionException {

		return dao.showStatus(application_id);
	}

	@Override
	public List<ProgramsScheduled> showProgramInfo(Date startdate, Date enddate)
			throws UniversityAdmissionException {

		return dao.showProgramInfo(startdate, enddate);
	}

	@Override
	public int getProgramId(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.getProgramId(programName);
	}

	// ////////////////////////////////////////////nehali
	@Override
	public List<ProgramsOffered> getAllProgramDetails()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.getAllProgramDetails();
	}

	@Override
	public String insertLocationDetails(Location loc)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.insertLocationDetails(loc);
	}

	@Override
	public boolean insertScheduledDetails(ProgramsScheduled schedule)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.insertScheduledDetails(schedule);
	}

	@Override
	public boolean deleteSchedule(String id)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.deleteSchedule(id);
	}

	// /////////////////////////////modified
	@Override
	public List<ProgramsScheduled> getAllProgramSheduled(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return dao.getAllProgramSheduled(programName);
	}
}
